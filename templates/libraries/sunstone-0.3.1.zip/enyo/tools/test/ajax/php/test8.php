<?php

header('Content-type: application/x-amf');
print('data');

?>