enyo.depends(
	"XhrTest.js",
	"AjaxTest.js",
	"JsonpTest.js",
	"WebServiceTest.js"
);
